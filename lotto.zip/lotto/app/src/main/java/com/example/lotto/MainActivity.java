package com.example.lotto;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    EditText[] inputs = new EditText[6];
    TextView[] results = new TextView[6];
    TextView matchCountText, drawCountText;
    int drawCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        inputs[0] = findViewById(R.id.num1);
        inputs[1] = findViewById(R.id.num2);
        inputs[2] = findViewById(R.id.num3);
        inputs[3] = findViewById(R.id.num4);
        inputs[4] = findViewById(R.id.num5);
        inputs[5] = findViewById(R.id.num6);


        results[0] = findViewById(R.id.draw1);
        results[1] = findViewById(R.id.draw2);
        results[2] = findViewById(R.id.draw3);
        results[3] = findViewById(R.id.draw4);
        results[4] = findViewById(R.id.draw5);
        results[5] = findViewById(R.id.draw6);

        matchCountText = findViewById(R.id.matchCount);
        drawCountText = findViewById(R.id.drawCounter);

        Button drawButton = findViewById(R.id.drawButton);
        Button resetButton = findViewById(R.id.resetButton);

        drawButton.setOnClickListener(v -> drawNumbers());
        resetButton.setOnClickListener(v -> resetGame());
    }

    void drawNumbers() {
        List<Integer> userNumbers = getUserInput();
        if (userNumbers == null) return;

        Set<Integer> drawn = new HashSet<>();
        Random rand = new Random();
        while (drawn.size() < 6) {
            drawn.add(rand.nextInt(49) + 1);
        }

        Integer[] drawnArray = drawn.toArray(new Integer[0]);
        Arrays.sort(drawnArray);
        for (int i = 0; i < 6; i++) {
            results[i].setText(String.valueOf(drawnArray[i]));
        }

        int matches = 0;
        for (Integer num : userNumbers) {
            if (drawn.contains(num)) matches++;
        }

        drawCount++;
        matchCountText.setText("Liczba trafień: " + matches);
        drawCountText.setText("Liczba losowań: " + drawCount);
    }

    List<Integer> getUserInput() {
        Set<Integer> values = new HashSet<>();
        try {
            for (EditText input : inputs) {
                int num = Integer.parseInt(input.getText().toString());
                if (num < 1 || num > 49) {
                    Toast.makeText(this, "Liczby muszą być z zakresu 1-49!", Toast.LENGTH_SHORT).show();
                    return null;
                }
                if (!values.add(num)) {
                    Toast.makeText(this, "Liczby muszą się różnić!", Toast.LENGTH_SHORT).show();
                    return null;
                }
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Uzupełnij wszystkie pola liczbami!", Toast.LENGTH_SHORT).show();
            return null;
        }
        return new ArrayList<>(values);
    }

    void resetGame() {
        for (EditText input : inputs) input.setText("");
        for (TextView res : results) res.setText("?");
        matchCountText.setText("Liczba trafień: 0");
        drawCountText.setText("Liczba losowań: 0");
        drawCount = 0;
    }
}
